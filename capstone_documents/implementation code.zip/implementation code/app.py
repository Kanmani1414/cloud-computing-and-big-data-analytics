"""
Big Data-Based Social Media Sentiment Analytics Platform - Main Flask Application
College Academic Project: Cloud Computing / Big Data / NLP
"""

import os
import sys
import io
import csv
import pandas as pd
from datetime import datetime
from flask import Flask, render_template, request, jsonify, send_file, Response
from flask_cors import CORS

from services.preprocessing import preprocess_dataset, clean_text
from services.spark_processor import run_spark_pipeline, configure_spark_env
from services.sentiment_analyzer import analyze_dataset_sentiment
from services.analytics import generate_complete_analytics, filter_dataset, compute_kpis

# Configure environment
configure_spark_env()

app = Flask(__name__, template_folder="templates", static_folder="static")
CORS(app)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
EXPORTS_DIR = os.path.join(BASE_DIR, "exports")
DEFAULT_CSV_PATH = os.path.join(DATA_DIR, "social_media_sentiment_analytics_1000.csv")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(EXPORTS_DIR, exist_ok=True)

# Application In-Memory State
APP_STATE = {
    "is_loaded": False,
    "is_processed": False,
    "raw_records": [],
    "analyzed_records": [],
    "spark_metadata": {},
    "nlp_comparison": {},
    "analytics": {},
    "dataset_info": {},
    "validation_info": {},
    "active_filename": "social_media_sentiment_analytics_1000.csv"
}

REQUIRED_COLUMNS = [
    "post_id", "platform", "timestamp", "username", "text", 
    "language", "topic", "sentiment", "sentiment_score", "emotion", 
    "likes", "shares", "comments", "hashtags", "location", "engagement_rate"
]


def validate_dataframe(df: pd.DataFrame) -> dict:
    """Validates dataframe schema, missing values, duplicates, and invalid timestamps."""
    missing_cols = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    
    total_records = len(df)
    missing_text = int(df["text"].isna().sum()) if "text" in df.columns else total_records
    duplicate_records = int(df.duplicated(subset=["post_id"]).sum()) if "post_id" in df.columns else 0
    
    # Check invalid timestamps
    invalid_timestamps = 0
    if "timestamp" in df.columns:
        for val in df["timestamp"]:
            try:
                datetime.strptime(str(val).split()[0], "%Y-%m-%d")
            except Exception:
                invalid_timestamps += 1

    platforms = sorted(df["platform"].dropna().unique().tolist()) if "platform" in df.columns else []
    languages = sorted(df["language"].dropna().unique().tolist()) if "language" in df.columns else []
    topics = sorted(df["topic"].dropna().unique().tolist()) if "topic" in df.columns else []
    
    min_date = str(df["timestamp"].min()) if "timestamp" in df.columns and not df["timestamp"].empty else "N/A"
    max_date = str(df["timestamp"].max()) if "timestamp" in df.columns and not df["timestamp"].empty else "N/A"
    date_range = f"{min_date[:10]} to {max_date[:10]}" if min_date != "N/A" else "N/A"

    is_valid = len(missing_cols) == 0 and total_records > 0

    return {
        "is_valid": is_valid,
        "total_records": total_records,
        "missing_text_count": missing_text,
        "duplicate_count": duplicate_records,
        "invalid_timestamps": invalid_timestamps,
        "missing_columns": missing_cols,
        "platform_count": len(platforms),
        "platforms": platforms,
        "language_count": len(languages),
        "languages": languages,
        "topic_count": len(topics),
        "topics": topics,
        "date_range": date_range,
        "status_label": "Valid" if is_valid else "Invalid Schema"
    }


def load_csv_data(filepath: str) -> tuple[bool, str]:
    """Loads and validates a CSV file into application state."""
    if not os.path.exists(filepath):
        return False, f"Dataset file not found at: {filepath}"

    try:
        df = pd.read_csv(filepath)
        # Normalize columns
        df.columns = [c.strip().lower() for c in df.columns]
        
        # Fill NA values safely
        if "likes" in df.columns: df["likes"] = df["likes"].fillna(0).astype(int)
        if "shares" in df.columns: df["shares"] = df["shares"].fillna(0).astype(int)
        if "comments" in df.columns: df["comments"] = df["comments"].fillna(0).astype(int)
        if "engagement_rate" in df.columns: df["engagement_rate"] = df["engagement_rate"].fillna(0.0).astype(float)
        if "sentiment_score" in df.columns: df["sentiment_score"] = df["sentiment_score"].fillna(0.0).astype(float)
        
        df["text"] = df["text"].fillna("")
        df["hashtags"] = df["hashtags"].fillna("")
        df["location"] = df["location"].fillna("Unknown")
        
        records = df.to_dict(orient="records")
        validation = validate_dataframe(df)
        
        APP_STATE["raw_records"] = records
        APP_STATE["is_loaded"] = True
        APP_STATE["is_processed"] = False
        APP_STATE["analyzed_records"] = []
        APP_STATE["validation_info"] = validation
        APP_STATE["dataset_info"] = {
            "filename": os.path.basename(filepath),
            "records_count": len(records),
            "columns": list(df.columns),
            "loaded_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        return True, "Dataset loaded successfully"
    except Exception as e:
        return False, f"Error reading CSV file: {str(e)}"


# Preload the default dataset on server start
if os.path.exists(DEFAULT_CSV_PATH):
    load_csv_data(DEFAULT_CSV_PATH)


# --- ROUTES ---

@app.route("/")
def index():
    """Serves the main single-page dashboard."""
    return render_template("index.html")


@app.route("/api/load-dataset", methods=["GET"])
def api_load_dataset():
    """Loads the default 1000-record dataset."""
    success, msg = load_csv_data(DEFAULT_CSV_PATH)
    if not success:
        return jsonify({"success": False, "error": msg}), 400

    # Provide first 20 records for initial preview table
    preview = APP_STATE["raw_records"][:20]
    
    return jsonify({
        "success": True,
        "message": msg,
        "dataset_info": APP_STATE["dataset_info"],
        "validation": APP_STATE["validation_info"],
        "preview_records": preview,
        "is_processed": APP_STATE["is_processed"]
    })


@app.route("/api/upload", methods=["POST"])
def api_upload():
    """Handles custom CSV file upload."""
    if "file" not in request.files:
        return jsonify({"success": False, "error": "No file uploaded"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"success": False, "error": "No selected file"}), 400

    if not file.filename.endswith(".csv"):
        return jsonify({"success": False, "error": "Only CSV files are supported"}), 400

    try:
        upload_path = os.path.join(DATA_DIR, f"uploaded_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{file.filename}")
        file.save(upload_path)
        
        success, msg = load_csv_data(upload_path)
        if not success:
            return jsonify({"success": False, "error": msg}), 400
            
        APP_STATE["active_filename"] = file.filename
        
        return jsonify({
            "success": True,
            "message": f"Uploaded and loaded {file.filename} successfully",
            "dataset_info": APP_STATE["dataset_info"],
            "validation": APP_STATE["validation_info"],
            "preview_records": APP_STATE["raw_records"][:20],
            "is_processed": False
        })
    except Exception as e:
        return jsonify({"success": False, "error": f"Upload processing failed: {str(e)}"}), 500


@app.route("/api/process", methods=["POST"])
def api_process():
    """
    Runs the complete academic pipeline:
    1. Preprocess text (clean, tokenize, remove stop words)
    2. Execute Apache Spark (PySpark DataFrame jobs & aggregations)
    3. Execute VADER NLP Sentiment Analysis & Classification
    4. Calculate Accuracy and Reference-vs-Predicted Benchmark
    5. Generate Aggregations & Dashboard Analytics
    """
    if not APP_STATE["is_loaded"] or not APP_STATE["raw_records"]:
        success, msg = load_csv_data(DEFAULT_CSV_PATH)
        if not success:
            return jsonify({"success": False, "error": "No dataset loaded to process"}), 400

    raw_records = APP_STATE["raw_records"]
    
    try:
        # Step 1: Text Preprocessing
        preprocessed_records = preprocess_dataset(raw_records)
        
        # Step 2: Apache Spark Processing
        spark_results = run_spark_pipeline(preprocessed_records)
        APP_STATE["spark_metadata"] = spark_results
        
        # Step 3: NLP Sentiment Analysis & Comparison
        analyzed_records, comparison_summary = analyze_dataset_sentiment(preprocessed_records)
        APP_STATE["analyzed_records"] = analyzed_records
        APP_STATE["nlp_comparison"] = comparison_summary
        
        # Step 4: Analytics Aggregation
        analytics = generate_complete_analytics(analyzed_records)
        APP_STATE["analytics"] = analytics
        
        APP_STATE["is_processed"] = True
        
        # Execution Checklist for UI
        checklist = [
            {"step": "Dataset Loaded", "status": "Completed", "detail": f"{len(raw_records)} records loaded"},
            {"step": "Data Validated", "status": "Completed", "detail": "Schema and column constraints verified"},
            {"step": "Text Preprocessed", "status": "Completed", "detail": "Lowercased, stripped URLs & mentions"},
            {"step": "Tokenization Completed", "status": "Completed", "detail": "Extracted word tokens"},
            {"step": "Stop-word Removal Completed", "status": "Completed", "detail": "NLTK English stopwords filtered"},
            {"step": "Apache Spark Processing Completed", "status": "Completed", "detail": f"PySpark RDD/DataFrame executed ({spark_results.get('execution_time_seconds', 0)}s)"},
            {"step": "NLP Sentiment Analysis Completed", "status": "Completed", "detail": "VADER compound polarity scoring executed"},
            {"step": "Sentiment Classification Completed", "status": "Completed", "detail": "Classified Positive / Negative / Neutral"},
            {"step": "Analytics Generated", "status": "Completed", "detail": "Keywords, hashtags, trends & distributions computed"},
            {"step": "Dashboard Updated", "status": "Completed", "detail": "KPI cards and interactive charts refreshed"}
        ]
        
        return jsonify({
            "success": True,
            "message": "Complete sentiment and Big Data processing pipeline executed successfully",
            "checklist": checklist,
            "spark_metadata": spark_results,
            "nlp_comparison": comparison_summary,
            "analytics": analytics,
            "total_records": len(analyzed_records)
        })
        
    except Exception as e:
        app.logger.error(f"Processing error: {e}", exc_info=True)
        return jsonify({"success": False, "error": f"Pipeline execution error: {str(e)}"}), 500


@app.route("/api/results", methods=["GET"])
def api_results():
    """
    Returns filtered and paginated records for the data tables.
    Supports search, pagination, and multi-column filtering.
    """
    # Use analyzed records if processed, otherwise raw records
    records = APP_STATE["analyzed_records"] if APP_STATE["is_processed"] else APP_STATE["raw_records"]
    
    if not records:
        return jsonify({
            "success": True,
            "records": [],
            "total": 0,
            "page": 1,
            "page_size": 10,
            "total_pages": 0
        })

    # Extract query filters
    filters = {
        "platform": request.args.get("platform", "all"),
        "sentiment": request.args.get("sentiment", "all"),
        "topic": request.args.get("topic", "all"),
        "language": request.args.get("language", "all"),
        "location": request.args.get("location", "all"),
        "search": request.args.get("search", ""),
        "start_date": request.args.get("start_date", ""),
        "end_date": request.args.get("end_date", "")
    }

    filtered = filter_dataset(records, filters)
    
    # Pagination
    try:
        page = max(1, int(request.args.get("page", 1)))
        page_size = max(1, min(100, int(request.args.get("page_size", 10))))
    except ValueError:
        page = 1
        page_size = 10

    total_filtered = len(filtered)
    total_pages = (total_filtered + page_size - 1) // page_size if total_filtered > 0 else 1
    
    start_idx = (page - 1) * page_size
    end_idx = start_idx + page_size
    page_records = filtered[start_idx:end_idx]

    return jsonify({
        "success": True,
        "records": page_records,
        "total": total_filtered,
        "page": page,
        "page_size": page_size,
        "total_pages": total_pages,
        "is_processed": APP_STATE["is_processed"]
    })


@app.route("/api/analytics", methods=["GET"])
def api_analytics():
    """
    Returns dynamically computed analytics for dashboard KPI cards and charts,
    re-computing on the fly if filters are provided.
    """
    records = APP_STATE["analyzed_records"] if APP_STATE["is_processed"] else APP_STATE["raw_records"]
    
    if not records:
        return jsonify({"success": False, "error": "No records available for analytics"}), 400

    filters = {
        "platform": request.args.get("platform", "all"),
        "sentiment": request.args.get("sentiment", "all"),
        "topic": request.args.get("topic", "all"),
        "language": request.args.get("language", "all"),
        "location": request.args.get("location", "all"),
        "search": request.args.get("search", ""),
        "start_date": request.args.get("start_date", ""),
        "end_date": request.args.get("end_date", "")
    }

    filtered_records = filter_dataset(records, filters)
    analytics = generate_complete_analytics(filtered_records)
    
    return jsonify({
        "success": True,
        "analytics": analytics,
        "spark_metadata": APP_STATE.get("spark_metadata", {}),
        "nlp_comparison": APP_STATE.get("nlp_comparison", {}),
        "total_records": len(filtered_records),
        "is_processed": APP_STATE["is_processed"]
    })


@app.route("/api/export", methods=["GET"])
def api_export():
    """
    Exports the analyzed dataset to CSV for download.
    """
    records = APP_STATE["analyzed_records"] if APP_STATE["is_processed"] else APP_STATE["raw_records"]
    
    if not records:
        return jsonify({"error": "No dataset to export"}), 400

    # Apply any active filters
    filters = {
        "platform": request.args.get("platform", "all"),
        "sentiment": request.args.get("sentiment", "all"),
        "topic": request.args.get("topic", "all"),
        "language": request.args.get("language", "all"),
        "location": request.args.get("location", "all"),
        "search": request.args.get("search", ""),
        "start_date": request.args.get("start_date", ""),
        "end_date": request.args.get("end_date", "")
    }
    
    filtered_records = filter_dataset(records, filters)
    
    # Generate CSV in memory
    output = io.StringIO()
    if filtered_records:
        fieldnames = list(filtered_records[0].keys())
        # Exclude internal non-serializable objects like token lists
        export_fields = [f for f in fieldnames if f not in ["tokens", "hashtag_list"]]
        
        writer = csv.DictWriter(output, fieldnames=export_fields, extrasaction="ignore")
        writer.writeheader()
        for row in filtered_records:
            writer.writerow(row)
            
    output.seek(0)
    
    filename = f"analyzed_sentiment_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment;filename={filename}"}
    )


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5050))
    print("\n=======================================================")
    print("  Big Data Social Media Sentiment Analytics Platform  ")
    print("  Local Spark & VADER NLP Cloud-Ready Engine          ")
    print("=======================================================\n")
    print(f"  -> Starting Flask Web Application on http://127.0.0.1:{port}")
    print("  -> Open this URL in your web browser to demonstrate.")
    print("=======================================================\n")
    app.run(host="127.0.0.1", port=port, debug=True)
