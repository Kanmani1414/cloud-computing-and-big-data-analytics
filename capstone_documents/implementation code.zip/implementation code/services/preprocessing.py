"""
Text Preprocessing Module for Social Media Sentiment Analytics Platform.
Implements data cleaning, text normalization, tokenization, and stop-word removal.
"""

import re
import string
import nltk

# Ensure NLTK stopwords and punkt are downloaded
try:
    nltk.data.find("corpora/stopwords")
except LookupError:
    nltk.download("stopwords", quiet=True)

try:
    nltk.data.find("tokenizers/punkt")
except LookupError:
    nltk.download("punkt", quiet=True)

try:
    nltk.data.find("tokenizers/punkt_tab")
except LookupError:
    nltk.download("punkt_tab", quiet=True)

try:
    from nltk.corpus import stopwords
    STOPWORDS = set(stopwords.words("english"))
except Exception:
    # Fallback standard English stop words
    STOPWORDS = {
        "i", "me", "my", "myself", "we", "our", "ours", "ourselves", "you", "your",
        "yours", "yourself", "yourselves", "he", "him", "his", "himself", "she",
        "her", "hers", "herself", "it", "its", "itself", "they", "them", "their",
        "theirs", "themselves", "what", "which", "who", "whom", "this", "that",
        "these", "those", "am", "is", "are", "was", "were", "be", "been", "being",
        "have", "has", "had", "having", "do", "does", "did", "doing", "a", "an",
        "the", "and", "but", "if", "or", "because", "as", "until", "while", "of",
        "at", "by", "for", "with", "about", "against", "between", "into", "through",
        "during", "before", "after", "above", "below", "to", "from", "up", "down",
        "in", "out", "on", "off", "over", "under", "again", "further", "then", "once",
        "here", "there", "when", "where", "why", "how", "all", "any", "both", "each",
        "few", "more", "most", "other", "some", "such", "no", "nor", "not", "only",
        "own", "same", "so", "than", "too", "very", "s", "t", "can", "will", "just",
        "don", "should", "now"
    }


def clean_text(raw_text: str) -> str:
    """
    Cleans and normalizes raw social media text:
    1. Converts to lowercase
    2. Removes URLs
    3. Removes @mentions
    4. Removes special characters while preserving alphabetic characters and words
    5. Normalizes whitespace
    """
    if not isinstance(raw_text, str):
        return ""
    
    text = raw_text.strip().lower()
    
    # Remove URLs (http, https, www)
    text = re.sub(r"https?://\S+|www\.\S+", "", text)
    
    # Remove @mentions
    text = re.sub(r"@\w+", "", text)
    
    # Remove hashtag symbol from word body for text cleaning (#AI -> AI)
    text = re.sub(r"#(\w+)", r"\1", text)
    
    # Remove punctuation & special characters (excluding spaces)
    text = re.sub(r"[^\w\s]", " ", text)
    
    # Replace numbers/digits if standalone
    text = re.sub(r"\b\d+\b", "", text)
    
    # Normalize multiple whitespace to single space
    text = re.sub(r"\s+", " ", text).strip()
    
    return text


def tokenize_and_remove_stopwords(cleaned_text: str) -> tuple[list[str], str]:
    """
    Tokenizes cleaned text, filters out English stop words,
    and returns a tuple of (token_list, processed_sentence).
    """
    if not cleaned_text:
        return [], ""
    
    tokens = cleaned_text.split()
    filtered_tokens = [t for t in tokens if t not in STOPWORDS and len(t) > 1]
    processed_text = " ".join(filtered_tokens)
    
    return filtered_tokens, processed_text


def extract_hashtags(hashtag_str: str) -> list[str]:
    """
    Extracts individual cleaned hashtags from the hashtags column string.
    Example: '#Shopping #OnlineShopping' -> ['#Shopping', '#OnlineShopping']
    """
    if not isinstance(hashtag_str, str):
        return []
    tags = re.findall(r"#\w+", hashtag_str)
    return [t.strip() for t in tags if t.strip()]


def preprocess_record(raw_text: str) -> dict:
    """
    Runs full preprocessing pipeline for a single post text.
    Preserves original_text alongside processed_text.
    """
    cleaned = clean_text(raw_text)
    tokens, processed = tokenize_and_remove_stopwords(cleaned)
    return {
        "original_text": raw_text,
        "cleaned_text": cleaned,
        "processed_text": processed,
        "tokens": tokens,
        "token_count": len(tokens)
    }


def preprocess_dataset(df_records: list[dict]) -> list[dict]:
    """
    Preprocesses a list of record dictionaries.
    Retains all original columns and adds 'original_text', 'processed_text', and 'tokens'.
    """
    processed_records = []
    for row in df_records:
        rec = dict(row)
        raw_text = str(rec.get("text", ""))
        rec["original_text"] = raw_text
        
        cleaned = clean_text(raw_text)
        tokens, processed = tokenize_and_remove_stopwords(cleaned)
        
        rec["processed_text"] = processed if processed else cleaned
        rec["tokens"] = tokens
        
        # Normalize hashtags list
        raw_hashtags = str(rec.get("hashtags", ""))
        rec["hashtag_list"] = extract_hashtags(raw_hashtags)
        
        processed_records.append(rec)
        
    return processed_records
