"""
NLP Sentiment Analysis Module using VADER (Valence Aware Dictionary and sEntiment Reasoner).
Performs actual polarity scoring, sentiment classification, and accuracy benchmarking.
"""

from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

# Initialize VADER Sentiment Analyzer
_vader_analyzer = SentimentIntensityAnalyzer()


def analyze_text_sentiment(text: str) -> dict:
    """
    Analyzes raw or processed text using VADER NLP.
    Returns polarity scores and the categorized sentiment label.
    """
    if not isinstance(text, str) or not text.strip():
        return {
            "predicted_sentiment": "Neutral",
            "predicted_score": 0.0,
            "compound": 0.0,
            "pos": 0.0,
            "neu": 1.0,
            "neg": 0.0
        }
    
    scores = _vader_analyzer.polarity_scores(text)
    compound = scores["compound"]
    
    # Standard VADER sentiment classification threshold
    if compound >= 0.05:
        predicted_sentiment = "Positive"
    elif compound <= -0.05:
        predicted_sentiment = "Negative"
    else:
        predicted_sentiment = "Neutral"
        
    return {
        "predicted_sentiment": predicted_sentiment,
        "predicted_score": round(compound, 4),
        "compound": round(compound, 4),
        "pos": round(scores["pos"], 4),
        "neu": round(scores["neu"], 4),
        "neg": round(scores["neg"], 4)
    }


def analyze_dataset_sentiment(records: list[dict]) -> tuple[list[dict], dict]:
    """
    Processes all records through the VADER NLP Sentiment Analyzer,
    enriches each record with predicted scores, and computes reference-vs-prediction comparison.
    """
    analyzed_records = []
    
    total = len(records)
    matching_count = 0
    different_count = 0
    
    sentiment_breakdown = {"Positive": 0, "Negative": 0, "Neutral": 0}
    reference_breakdown = {"Positive": 0, "Negative": 0, "Neutral": 0}
    
    # Class-level match tracking
    class_matches = {"Positive": 0, "Negative": 0, "Neutral": 0}
    
    total_compound_score = 0.0

    for r in records:
        rec = dict(r)
        
        # Analyze the original text for sentiment (or processed text)
        text_to_analyze = rec.get("original_text") or rec.get("text", "")
        vader_res = analyze_text_sentiment(text_to_analyze)
        
        rec["predicted_sentiment"] = vader_res["predicted_sentiment"]
        rec["predicted_score"] = vader_res["predicted_score"]
        rec["vader_compound"] = vader_res["compound"]
        rec["vader_pos"] = vader_res["pos"]
        rec["vader_neu"] = vader_res["neu"]
        rec["vader_neg"] = vader_res["neg"]
        
        # Track statistics
        pred_sent = rec["predicted_sentiment"]
        ref_sent = str(rec.get("sentiment", "")).strip().capitalize()
        
        # Normalize reference sentiment to Positive/Negative/Neutral
        if "pos" in ref_sent.lower():
            ref_sent = "Positive"
        elif "neg" in ref_sent.lower():
            ref_sent = "Negative"
        else:
            ref_sent = "Neutral"
        rec["reference_sentiment"] = ref_sent
        
        sentiment_breakdown[pred_sent] = sentiment_breakdown.get(pred_sent, 0) + 1
        reference_breakdown[ref_sent] = reference_breakdown.get(ref_sent, 0) + 1
        total_compound_score += vader_res["compound"]
        
        is_match = (pred_sent == ref_sent)
        rec["sentiment_match"] = is_match
        
        if is_match:
            matching_count += 1
            class_matches[ref_sent] = class_matches.get(ref_sent, 0) + 1
        else:
            different_count += 1
            
        analyzed_records.append(rec)
        
    accuracy = round((matching_count / total * 100), 2) if total > 0 else 0.0
    avg_score = round(total_compound_score / total, 4) if total > 0 else 0.0
    
    comparison_summary = {
        "total_records": total,
        "matching_predictions": matching_count,
        "different_predictions": different_count,
        "accuracy_percentage": accuracy,
        "avg_predicted_score": avg_score,
        "predicted_distribution": sentiment_breakdown,
        "reference_distribution": reference_breakdown,
        "class_matches": class_matches,
        "positive_count": sentiment_breakdown["Positive"],
        "negative_count": sentiment_breakdown["Negative"],
        "neutral_count": sentiment_breakdown["Neutral"],
        "positive_pct": round((sentiment_breakdown["Positive"] / total * 100), 2) if total > 0 else 0.0,
        "negative_pct": round((sentiment_breakdown["Negative"] / total * 100), 2) if total > 0 else 0.0,
        "neutral_pct": round((sentiment_breakdown["Neutral"] / total * 100), 2) if total > 0 else 0.0,
        "nlp_model": "VADER (Valence Aware Dictionary and sEntiment Reasoner)",
        "language_note": "NLP sentiment analysis is optimized for English text; regional-language and Hinglish records may have reduced accuracy."
    }
    
    return analyzed_records, comparison_summary
