"""
Apache Spark Big Data Processing Engine for Social Media Analytics.
Executes genuine PySpark DataFrame jobs in local mode for distributed data aggregation.
"""

import os
import sys
import time
import logging

logger = logging.getLogger(__name__)

# Configure Java and PySpark Python executable for Windows environment
def configure_spark_env():
    # Set JAVA_HOME if not already in environment
    if not os.environ.get("JAVA_HOME"):
        default_jdk = r"C:\Program Files\Microsoft\jdk-17.0.20.101-hotspot"
        if os.path.exists(default_jdk):
            os.environ["JAVA_HOME"] = default_jdk
            os.environ["PATH"] = os.path.join(default_jdk, "bin") + ";" + os.environ.get("PATH", "")
    
    # Ensure PySpark workers use the exact current Python interpreter
    os.environ["PYSPARK_PYTHON"] = sys.executable
    os.environ["PYSPARK_DRIVER_PYTHON"] = sys.executable

configure_spark_env()

# Global Spark Session Holder
_spark_session = None


def get_spark_session():
    """
    Initializes and returns a singleton SparkSession configured for fast local execution.
    """
    global _spark_session
    if _spark_session is not None:
        try:
            if not _spark_session.sparkContext._jsc.sc().isStopped():
                return _spark_session
        except Exception:
            _spark_session = None

    configure_spark_env()
    
    from pyspark.sql import SparkSession
    
    builder = (
        SparkSession.builder
        .appName("SocialMediaSentimentAnalyticsEngine")
        .master("local[2]")
        .config("spark.driver.bindAddress", "127.0.0.1")
        .config("spark.driver.host", "127.0.0.1")
        .config("spark.ui.enabled", "false")
        .config("spark.sql.execution.arrow.pyspark.enabled", "false")
        .config("spark.sql.shuffle.partitions", "2")
        .config("spark.default.parallelism", "2")
        .config("spark.executor.memory", "1g")
        .config("spark.driver.memory", "1g")
    )
    
    _spark_session = builder.getOrCreate()
    _spark_session.sparkContext.setLogLevel("WARN")
    return _spark_session


def run_spark_pipeline(records: list[dict]) -> dict:
    """
    Executes actual PySpark DataFrame transformations and distributed aggregations
    on the social media dataset.
    """
    if not records:
        return {
            "status": "Error",
            "message": "Empty dataset provided to Spark Engine",
            "records_processed": 0,
            "mode": "Local Spark Demonstration (local[2])",
            "execution_time_seconds": 0.0,
        }

    start_time = time.time()
    
    try:
        spark = get_spark_session()
        
        # Clean records for PySpark DataFrame compatibility
        clean_rows = []
        for r in records:
            clean_rows.append({
                "post_id": str(r.get("post_id", "")),
                "platform": str(r.get("platform", "")),
                "timestamp": str(r.get("timestamp", "")),
                "username": str(r.get("username", "")),
                "text": str(r.get("text", "")),
                "processed_text": str(r.get("processed_text", "")),
                "language": str(r.get("language", "")),
                "topic": str(r.get("topic", "")),
                "sentiment": str(r.get("sentiment", "")),
                "sentiment_score": float(r.get("sentiment_score", 0.0) or 0.0),
                "emotion": str(r.get("emotion", "")),
                "likes": int(r.get("likes", 0) or 0),
                "shares": int(r.get("shares", 0) or 0),
                "comments": int(r.get("comments", 0) or 0),
                "hashtags": str(r.get("hashtags", "")),
                "location": str(r.get("location", "")),
                "engagement_rate": float(r.get("engagement_rate", 0.0) or 0.0)
            })
            
        # 1. Create Spark DataFrame
        spark_df = spark.createDataFrame(clean_rows)
        spark_df.createOrReplaceTempView("social_media_posts")
        
        record_count = spark_df.count()
        num_partitions = spark_df.rdd.getNumPartitions()
        
        # 2. PySpark GroupBy Aggregations: Platform Analytics
        from pyspark.sql.functions import avg, count, sum as spark_sum, round as spark_round, col
        
        platform_stats = (
            spark_df.groupBy("platform")
            .agg(
                count("*").alias("post_count"),
                spark_round(avg("likes"), 2).alias("avg_likes"),
                spark_round(avg("shares"), 2).alias("avg_shares"),
                spark_round(avg("comments"), 2).alias("avg_comments"),
                spark_round(avg("engagement_rate"), 2).alias("avg_engagement")
            )
            .orderBy(col("post_count").desc())
            .collect()
        )
        platform_summary = [row.asDict() for row in platform_stats]
        
        # 3. PySpark GroupBy Aggregations: Topic Sentiment Distribution
        topic_stats = (
            spark_df.groupBy("topic")
            .agg(
                count("*").alias("post_count"),
                spark_round(avg("sentiment_score"), 4).alias("avg_sentiment_score"),
                spark_round(avg("engagement_rate"), 2).alias("avg_engagement")
            )
            .orderBy(col("post_count").desc())
            .collect()
        )
        topic_summary = [row.asDict() for row in topic_stats]
        
        # 4. PySpark SQL Engine Query
        sql_summary = spark.sql("""
            SELECT 
                sentiment,
                COUNT(*) as count,
                ROUND(AVG(sentiment_score), 4) as avg_score,
                SUM(likes) as total_likes,
                SUM(shares) as total_shares,
                SUM(comments) as total_comments
            FROM social_media_posts
            GROUP BY sentiment
            ORDER BY count DESC
        """).collect()
        sentiment_summary = [row.asDict() for row in sql_summary]
        
        # 5. Language Statistics via Spark
        lang_stats = (
            spark_df.groupBy("language")
            .count()
            .orderBy(col("count").desc())
            .collect()
        )
        language_summary = [row.asDict() for row in lang_stats]
        
        execution_time = round(time.time() - start_time, 3)
        
        return {
            "status": "Completed",
            "records_processed": record_count,
            "mode": "Local Spark Demonstration (local[2])",
            "spark_version": spark.version,
            "num_partitions": num_partitions,
            "execution_time_seconds": execution_time,
            "platform_summary": platform_summary,
            "topic_summary": topic_summary,
            "sentiment_summary": sentiment_summary,
            "language_summary": language_summary,
            "engine": "Apache Spark (PySpark Distributed RDD/DataFrame Engine)"
        }
        
    except Exception as e:
        logger.error(f"Spark processing error: {e}", exc_info=True)
        return {
            "status": "Error",
            "error_message": str(e),
            "records_processed": len(records),
            "mode": "Local Spark Demonstration (local[2])",
            "execution_time_seconds": round(time.time() - start_time, 3)
        }


def stop_spark():
    """Stops the active SparkSession."""
    global _spark_session
    if _spark_session is not None:
        try:
            _spark_session.stop()
        except Exception:
            pass
        _spark_session = None
