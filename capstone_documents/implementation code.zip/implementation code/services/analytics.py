"""
Analytics & Aggregation Service for Social Media Sentiment Platform.
Dynamically calculates KPIs, keyword/hashtag frequencies, temporal trends,
platform/topic distributions, emotion breakdowns, and engagement metrics.
"""

from collections import Counter
from datetime import datetime
import re


def compute_kpis(records: list[dict]) -> dict:
    """Computes headline Key Performance Indicators from records."""
    total = len(records)
    if total == 0:
        return {
            "total_posts": 0,
            "positive_count": 0,
            "negative_count": 0,
            "neutral_count": 0,
            "positive_pct": 0.0,
            "negative_pct": 0.0,
            "neutral_pct": 0.0,
            "avg_sentiment_score": 0.0,
            "avg_engagement_rate": 0.0,
            "total_likes": 0,
            "total_shares": 0,
            "total_comments": 0,
        }

    pos_count = sum(1 for r in records if r.get("predicted_sentiment") == "Positive")
    neg_count = sum(1 for r in records if r.get("predicted_sentiment") == "Negative")
    neu_count = sum(1 for r in records if r.get("predicted_sentiment") == "Neutral")
    
    total_score = sum(float(r.get("predicted_score", 0.0) or 0.0) for r in records)
    total_eng = sum(float(r.get("engagement_rate", 0.0) or 0.0) for r in records)
    
    total_likes = sum(int(r.get("likes", 0) or 0) for r in records)
    total_shares = sum(int(r.get("shares", 0) or 0) for r in records)
    total_comments = sum(int(r.get("comments", 0) or 0) for r in records)

    return {
        "total_posts": total,
        "positive_count": pos_count,
        "negative_count": neg_count,
        "neutral_count": neu_count,
        "positive_pct": round((pos_count / total) * 100, 1),
        "negative_pct": round((neg_count / total) * 100, 1),
        "neutral_pct": round((neu_count / total) * 100, 1),
        "avg_sentiment_score": round(total_score / total, 3),
        "avg_engagement_rate": round(total_eng / total, 2),
        "total_likes": total_likes,
        "total_shares": total_shares,
        "total_comments": total_comments,
    }


def compute_top_keywords(records: list[dict], top_n: int = 15) -> list[dict]:
    """Extracts top frequent keywords from tokenized processed text."""
    word_counter = Counter()
    
    for r in records:
        tokens = r.get("tokens", [])
        if not tokens and r.get("processed_text"):
            tokens = r["processed_text"].split()
        for tok in tokens:
            word = tok.lower().strip()
            # Filter out non-alphabetic or very short tokens
            if len(word) > 2 and word.isalpha():
                word_counter[word] += 1

    top_words = word_counter.most_common(top_n)
    return [{"word": w, "count": c} for w, c in top_words]


def compute_top_hashtags(records: list[dict], top_n: int = 12) -> list[dict]:
    """Extracts top hashtags and their frequencies from the dataset."""
    hashtag_counter = Counter()
    
    for r in records:
        raw_ht = str(r.get("hashtags", ""))
        tags = re.findall(r"#\w+", raw_ht)
        for tag in tags:
            tag_clean = tag.strip()
            if tag_clean:
                hashtag_counter[tag_clean] += 1

    top_tags = hashtag_counter.most_common(top_n)
    return [{"hashtag": tag, "count": c} for tag, c in top_tags]


def compute_sentiment_trend(records: list[dict]) -> dict:
    """
    Groups posts by date/month and calculates positive, negative,
    neutral counts and average sentiment score for trend charts.
    """
    date_map = {}
    
    for r in records:
        ts = str(r.get("timestamp", ""))
        date_key = "Unknown"
        if ts:
            try:
                # Format to YYYY-MM or YYYY-MM-DD
                dt = datetime.strptime(ts.split()[0], "%Y-%m-%d")
                date_key = dt.strftime("%Y-%m") # Monthly grouping for clean visual trends
            except Exception:
                date_key = ts[:7] if len(ts) >= 7 else "Unknown"
                
        if date_key not in date_map:
            date_map[date_key] = {"Positive": 0, "Negative": 0, "Neutral": 0, "total_score": 0.0, "count": 0}
            
        sent = r.get("predicted_sentiment", "Neutral")
        if sent not in date_map[date_key]:
            sent = "Neutral"
        date_map[date_key][sent] += 1
        date_map[date_key]["total_score"] += float(r.get("predicted_score", 0.0) or 0.0)
        date_map[date_key]["count"] += 1

    # Sort chronological
    sorted_dates = sorted([k for k in date_map.keys() if k != "Unknown"])
    if "Unknown" in date_map:
        sorted_dates.append("Unknown")

    labels = []
    positive_data = []
    negative_data = []
    neutral_data = []
    avg_scores = []

    for d in sorted_dates:
        labels.append(d)
        positive_data.append(date_map[d]["Positive"])
        negative_data.append(date_map[d]["Negative"])
        neutral_data.append(date_map[d]["Neutral"])
        cnt = date_map[d]["count"]
        avg_scores.append(round(date_map[d]["total_score"] / cnt, 3) if cnt > 0 else 0.0)

    return {
        "labels": labels,
        "positive": positive_data,
        "negative": negative_data,
        "neutral": neutral_data,
        "avg_scores": avg_scores
    }


def compute_platform_analytics(records: list[dict]) -> dict:
    """Calculates sentiment distribution and engagement by social media platform."""
    platform_map = {}
    
    for r in records:
        p = str(r.get("platform", "Other")).strip() or "Other"
        if p not in platform_map:
            platform_map[p] = {
                "platform": p,
                "total": 0,
                "positive": 0,
                "negative": 0,
                "neutral": 0,
                "likes": 0,
                "shares": 0,
                "comments": 0,
                "total_eng": 0.0
            }
            
        platform_map[p]["total"] += 1
        sent = r.get("predicted_sentiment", "Neutral")
        if sent == "Positive":
            platform_map[p]["positive"] += 1
        elif sent == "Negative":
            platform_map[p]["negative"] += 1
        else:
            platform_map[p]["neutral"] += 1
            
        platform_map[p]["likes"] += int(r.get("likes", 0) or 0)
        platform_map[p]["shares"] += int(r.get("shares", 0) or 0)
        platform_map[p]["comments"] += int(r.get("comments", 0) or 0)
        platform_map[p]["total_eng"] += float(r.get("engagement_rate", 0.0) or 0.0)

    table_data = []
    labels = []
    positive_series = []
    negative_series = []
    neutral_series = []

    # Sort platforms by total posts descending
    for p, stats in sorted(platform_map.items(), key=lambda x: x[1]["total"], reverse=True):
        labels.append(p)
        positive_series.append(stats["positive"])
        negative_series.append(stats["negative"])
        neutral_series.append(stats["neutral"])
        
        cnt = stats["total"]
        table_data.append({
            "platform": p,
            "total_posts": cnt,
            "positive": stats["positive"],
            "negative": stats["negative"],
            "neutral": stats["neutral"],
            "avg_engagement": round(stats["total_eng"] / cnt, 2) if cnt > 0 else 0.0,
            "total_likes": stats["likes"],
            "total_shares": stats["shares"],
            "total_comments": stats["comments"]
        })

    return {
        "labels": labels,
        "positive": positive_series,
        "negative": negative_series,
        "neutral": neutral_series,
        "table": table_data
    }


def compute_topic_analytics(records: list[dict]) -> dict:
    """Calculates sentiment distribution across different topics."""
    topic_map = {}
    
    for r in records:
        t = str(r.get("topic", "General")).strip() or "General"
        if t not in topic_map:
            topic_map[t] = {"total": 0, "positive": 0, "negative": 0, "neutral": 0}
        
        topic_map[t]["total"] += 1
        sent = r.get("predicted_sentiment", "Neutral")
        if sent == "Positive":
            topic_map[t]["positive"] += 1
        elif sent == "Negative":
            topic_map[t]["negative"] += 1
        else:
            topic_map[t]["neutral"] += 1

    labels = []
    positive_data = []
    negative_data = []
    neutral_data = []

    for t, stats in sorted(topic_map.items(), key=lambda x: x[1]["total"], reverse=True):
        labels.append(t)
        positive_data.append(stats["positive"])
        negative_data.append(stats["negative"])
        neutral_data.append(stats["neutral"])

    return {
        "labels": labels,
        "positive": positive_data,
        "negative": negative_data,
        "neutral": neutral_data
    }


def compute_language_analytics(records: list[dict]) -> dict:
    """Calculates post distribution and sentiment by language."""
    lang_map = {}
    
    for r in records:
        lang = str(r.get("language", "English")).strip() or "English"
        if lang not in lang_map:
            lang_map[lang] = {"total": 0, "positive": 0, "negative": 0, "neutral": 0}
        lang_map[lang]["total"] += 1
        sent = r.get("predicted_sentiment", "Neutral")
        if sent == "Positive":
            lang_map[lang]["positive"] += 1
        elif sent == "Negative":
            lang_map[lang]["negative"] += 1
        else:
            lang_map[lang]["neutral"] += 1

    languages = []
    for l, stats in sorted(lang_map.items(), key=lambda x: x[1]["total"], reverse=True):
        languages.append({
            "language": l,
            "count": stats["total"],
            "positive": stats["positive"],
            "negative": stats["negative"],
            "neutral": stats["neutral"],
            "pct": round(stats["total"] / len(records) * 100, 1) if records else 0.0
        })

    return {
        "languages": languages,
        "note": "NLP sentiment analysis is optimized for English text; regional-language and Hinglish records may have reduced accuracy."
    }


def compute_emotion_analytics(records: list[dict]) -> dict:
    """Aggregates emotion column distribution from dataset."""
    emotion_counter = Counter()
    for r in records:
        em = str(r.get("emotion", "neutral")).strip().lower()
        if em:
            emotion_counter[em] += 1

    labels = []
    counts = []
    for em, count in emotion_counter.most_common():
        labels.append(em.capitalize())
        counts.append(count)

    return {
        "labels": labels,
        "counts": counts
    }


def compute_engagement_analytics(records: list[dict]) -> dict:
    """Computes engagement metrics categorized by sentiment and finds top posts."""
    by_sentiment = {
        "Positive": {"count": 0, "likes": 0, "shares": 0, "comments": 0, "eng_rate": 0.0},
        "Negative": {"count": 0, "likes": 0, "shares": 0, "comments": 0, "eng_rate": 0.0},
        "Neutral": {"count": 0, "likes": 0, "shares": 0, "comments": 0, "eng_rate": 0.0}
    }

    for r in records:
        sent = r.get("predicted_sentiment", "Neutral")
        if sent not in by_sentiment:
            sent = "Neutral"
        by_sentiment[sent]["count"] += 1
        by_sentiment[sent]["likes"] += int(r.get("likes", 0) or 0)
        by_sentiment[sent]["shares"] += int(r.get("shares", 0) or 0)
        by_sentiment[sent]["comments"] += int(r.get("comments", 0) or 0)
        by_sentiment[sent]["eng_rate"] += float(r.get("engagement_rate", 0.0) or 0.0)

    # Average engagement rates per sentiment
    categories = ["Positive", "Negative", "Neutral"]
    avg_likes = []
    avg_shares = []
    avg_comments = []
    avg_eng = []

    for cat in categories:
        cnt = by_sentiment[cat]["count"]
        if cnt > 0:
            avg_likes.append(round(by_sentiment[cat]["likes"] / cnt, 1))
            avg_shares.append(round(by_sentiment[cat]["shares"] / cnt, 1))
            avg_comments.append(round(by_sentiment[cat]["comments"] / cnt, 1))
            avg_eng.append(round(by_sentiment[cat]["eng_rate"] / cnt, 2))
        else:
            avg_likes.append(0)
            avg_shares.append(0)
            avg_comments.append(0)
            avg_eng.append(0.0)

    # Find Top 5 Most Engaged Posts
    sorted_by_engagement = sorted(
        records,
        key=lambda x: (float(x.get("engagement_rate", 0.0) or 0.0), int(x.get("likes", 0) or 0)),
        reverse=True
    )[:5]

    top_posts = []
    for p in sorted_by_engagement:
        top_posts.append({
            "post_id": p.get("post_id"),
            "platform": p.get("platform"),
            "username": p.get("username"),
            "text": p.get("text"),
            "sentiment": p.get("predicted_sentiment"),
            "likes": int(p.get("likes", 0) or 0),
            "shares": int(p.get("shares", 0) or 0),
            "comments": int(p.get("comments", 0) or 0),
            "engagement_rate": float(p.get("engagement_rate", 0.0) or 0.0)
        })

    return {
        "categories": categories,
        "avg_likes": avg_likes,
        "avg_shares": avg_shares,
        "avg_comments": avg_comments,
        "avg_engagement_rate": avg_eng,
        "top_posts": top_posts
    }


def compute_location_analytics(records: list[dict], top_n: int = 10) -> list[dict]:
    """Groups posts by location with counts and sentiment breakdown."""
    loc_map = {}
    for r in records:
        loc = str(r.get("location", "Unknown")).strip() or "Unknown"
        if loc not in loc_map:
            loc_map[loc] = {"location": loc, "count": 0, "positive": 0, "negative": 0, "neutral": 0}
        loc_map[loc]["count"] += 1
        sent = r.get("predicted_sentiment", "Neutral")
        if sent == "Positive":
            loc_map[loc]["positive"] += 1
        elif sent == "Negative":
            loc_map[loc]["negative"] += 1
        else:
            loc_map[loc]["neutral"] += 1

    sorted_locs = sorted(loc_map.values(), key=lambda x: x["count"], reverse=True)[:top_n]
    return sorted_locs


def filter_dataset(records: list[dict], filters: dict) -> list[dict]:
    """Filters records by platform, sentiment, topic, language, location, date range, and search."""
    if not filters:
        return records

    platform_filter = filters.get("platform")
    sentiment_filter = filters.get("sentiment")
    topic_filter = filters.get("topic")
    language_filter = filters.get("language")
    location_filter = filters.get("location")
    search_query = filters.get("search", "").strip().lower()
    start_date = filters.get("start_date")
    end_date = filters.get("end_date")

    filtered = []
    for r in records:
        # Platform match
        if platform_filter and platform_filter != "all":
            if str(r.get("platform", "")).lower() != platform_filter.lower():
                continue

        # Sentiment match (check predicted sentiment or reference)
        if sentiment_filter and sentiment_filter != "all":
            pred = str(r.get("predicted_sentiment", "")).lower()
            if pred != sentiment_filter.lower():
                continue

        # Topic match
        if topic_filter and topic_filter != "all":
            if str(r.get("topic", "")).lower() != topic_filter.lower():
                continue

        # Language match
        if language_filter and language_filter != "all":
            if str(r.get("language", "")).lower() != language_filter.lower():
                continue

        # Location match
        if location_filter and location_filter != "all":
            if str(r.get("location", "")).lower() != location_filter.lower():
                continue

        # Date range match
        if start_date or end_date:
            ts = str(r.get("timestamp", ""))[:10]
            if start_date and ts < start_date:
                continue
            if end_date and ts > end_date:
                continue

        # Text search match (searches post_id, username, text, processed_text, hashtags, topic)
        if search_query:
            searchable_blob = f"{r.get('post_id', '')} {r.get('username', '')} {r.get('text', '')} {r.get('processed_text', '')} {r.get('hashtags', '')} {r.get('topic', '')}".lower()
            if search_query not in searchable_blob:
                continue

        filtered.append(r)

    return filtered


def generate_complete_analytics(records: list[dict]) -> dict:
    """Generates the full analytics payload for the dashboard."""
    return {
        "kpis": compute_kpis(records),
        "sentiment_distribution": {
            "Positive": sum(1 for r in records if r.get("predicted_sentiment") == "Positive"),
            "Negative": sum(1 for r in records if r.get("predicted_sentiment") == "Negative"),
            "Neutral": sum(1 for r in records if r.get("predicted_sentiment") == "Neutral")
        },
        "top_keywords": compute_top_keywords(records, top_n=15),
        "top_hashtags": compute_top_hashtags(records, top_n=12),
        "sentiment_trend": compute_sentiment_trend(records),
        "platform_analytics": compute_platform_analytics(records),
        "topic_analytics": compute_topic_analytics(records),
        "language_analytics": compute_language_analytics(records),
        "emotion_analytics": compute_emotion_analytics(records),
        "engagement_analytics": compute_engagement_analytics(records),
        "location_analytics": compute_location_analytics(records, top_n=10)
    }
