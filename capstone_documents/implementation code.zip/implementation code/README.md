# Big Data-Based Social Media Sentiment Analytics Platform

> **Academic Project**: Cloud Computing / Big Data Analytics / Natural Language Processing (NLP)  
> **Architecture**: Cloud-Ready Distributed Pipeline (Local Academic Demonstration)

---

## 1. Project Title & Abstract

### Title
**Big Data-Based Social Media Sentiment Analytics Platform**

### Abstract
Social media generates massive volumes of user opinions and real-time commentary across diverse domains such as E-commerce, Technology, Finance, Education, Healthcare, and Entertainment. This project presents an end-to-end, big data-powered analytics platform that ingests multi-platform social media streams, cleans and tokenizes textual records, executes distributed batch aggregations using **Apache Spark (PySpark)**, performs valence-aware sentiment classification using **VADER NLP**, benchmarks model predictions against reference labels, and renders real-time interactive insights via a modern web-based **Visualization Dashboard**.

---

## 2. The Three Core Project Modules

The platform is designed with a clear, modular architecture:

```
+-------------------------------------------------------------------------------+
| MODULE 1: Social Media Data Collection & Validation Module                    |
| - Benchmark Ingestion (1,000 Multi-Platform Social Media Posts)              |
| - Custom CSV Upload & Header/Schema Validation                                |
| - Data Health Audit (Missing Values, Deduplication, Timestamp Integrity)     |
| - Searchable, Paginated Raw Data Preview                                      |
+-------------------------------------------------------------------------------+
                                      |
                                      v
+-------------------------------------------------------------------------------+
| MODULE 2: Sentiment Analysis & Big Data Processing Engine                     |
| - Data Cleaning (URL removal, mention stripping, whitespace normalization)    |
| - Tokenization & Stop-word Filtering (NLTK English Corpus)                    |
| - Apache Spark Processing (PySpark DataFrame Transformations in local[*] mode)|
| - NLP Sentiment Analysis & Classification (VADER Polarity Scoring)            |
| - Reference vs. Prediction Accuracy Benchmarking                              |
+-------------------------------------------------------------------------------+
                                      |
                                      v
+-------------------------------------------------------------------------------+
| MODULE 3: Cloud-Based Visualization Dashboard                                 |
| - Real-Time KPI Cards (Total Posts, Positive/Negative/Neutral %, Scores, Eng) |
| - 8 Dynamic Chart.js Visualizations (Distributions, Trends, Topics, Emotions) |
| - Cross-Dimensional Filtering (Platform, Topic, Sentiment, Language, Location)|
| - Analyzed Data Explorer & Downloadable CSV Export                            |
+-------------------------------------------------------------------------------+
```

---

## 3. Technology Stack

* **Backend Web Framework**: Python 3, Flask, Flask-CORS
* **Big Data Processing**: Apache Spark, PySpark (DataFrame & Spark SQL Engines)
* **Natural Language Processing (NLP)**: NLTK, VADER (`SentimentIntensityAnalyzer`)
* **Data Manipulation**: Pandas, NumPy
* **Frontend User Interface**: HTML5, CSS3 (Glassmorphism Dark Theme), JavaScript (ES6+)
* **Interactive Charting Engine**: Chart.js 4.4
* **Runtime / Environment**: Microsoft OpenJDK 17, Python 3.10+ on Windows / Linux / macOS

---

## 4. Project Directory Structure

```text
social_media_sentiment_platform/
│
├── app.py                      # Main Flask application and REST API endpoints
├── requirements.txt            # Python package dependencies
├── README.md                   # Complete academic project documentation
├── .gitignore                  # Git ignore rules
│
├── data/
│   └── social_media_sentiment_analytics_1000.csv   # Benchmark 1,000-post dataset
│
├── services/
│   ├── __init__.py             # Package initializer
│   ├── preprocessing.py        # Text cleaning, normalization, tokenization, stop-words
│   ├── spark_processor.py      # PySpark Session, DataFrame aggregation, Spark SQL
│   ├── sentiment_analyzer.py   # VADER NLP sentiment scoring & accuracy benchmarking
│   └── analytics.py            # Dynamic KPI calculation, trend aggregation, filtering
│
├── templates/
│   └── index.html              # Modern single-page analytics dashboard template
│
├── static/
│   ├── css/
│   │   └── style.css           # Glassmorphism dark data-analytics theme
│   └── js/
│       └── app.js              # Chart.js rendering, filter reactivity, table pagination
│
└── exports/                    # Output directory for exported analyzed CSV files
```

---

## 5. Dataset Information

The platform operates on the benchmark file: `data/social_media_sentiment_analytics_1000.csv` containing **1,000 records** across **16 structured attributes**:

| Field | Description | Example |
| :--- | :--- | :--- |
| `post_id` | Unique post identifier | `SM_0001` |
| `platform` | Social network source | `Instagram`, `YouTube`, `Facebook`, `Twitter/X`, `Reddit` |
| `timestamp` | Publication date and time | `2026-01-08 02:13:00` |
| `username` | Author user handle | `user_76237` |
| `text` | Raw social media post content | `Very disappointed with the latest E-commerce update.` |
| `language` | Language classification | `English`, `Hinglish`, `Tamil` |
| `topic` | Industry / Subject category | `E-commerce`, `Technology`, `Finance`, `Healthcare`, etc. |
| `sentiment` | Ground truth / Reference label | `Positive`, `Negative`, `Neutral` |
| `sentiment_score` | Original reference score | `-0.664` |
| `emotion` | Affective state label | `sadness`, `joy`, `anger`, `excitement`, `calm`, etc. |
| `likes` | Interaction count: Likes | `35741` |
| `shares` | Interaction count: Retweets / Shares | `356` |
| `comments` | Interaction count: Comments | `1728` |
| `hashtags` | Social media hashtags | `#Shopping #Deals` |
| `location` | Geographic origin | `Bengaluru`, `Delhi`, `Mumbai`, `Online`, etc. |
| `engagement_rate` | Normalized engagement metric | `100.0%` |

---

## 6. How Apache Spark & NLP Work in this Project

### Apache Spark (PySpark) Engine
* **Local Mode Configuration**: Initializes a `SparkSession` in `local[*]` mode utilizing all available CPU cores on the local machine.
* **Distributed DataFrame Operations**:
  * Loads records into a partitioned Spark DataFrame.
  * Registers in-memory temporary views (`social_media_posts`).
  * Executes Spark SQL queries and `groupBy().agg()` operations for platform metrics, topic distributions, and engagement calculations.
  * Demonstrates how big data aggregations scale seamlessly when deployed to a distributed cloud cluster (such as AWS EMR, Azure Synapse, or Dataproc).

### NLP Sentiment Analysis (VADER)
* **Lexicon & Valence Scoring**: Evaluates punctuation intensity, capitalization, negation, and sentiment valence words to calculate compound polarity scores ranging from **-1.0 (Most Negative)** to **+1.0 (Most Positive)**.
* **Classification Thresholds**:
  * Compound Score $\ge +0.05 \implies$ **Positive**
  * Compound Score $\le -0.05 \implies$ **Negative**
  * $-0.05 < \text{Compound Score} < +0.05 \implies$ **Neutral**
* **Dynamic Ground-Truth Benchmarking**: The NLP predicted class is compared against the dataset's reference `sentiment` column to dynamically calculate the genuine accuracy percentage and agreement rate.

---

## 7. Installation & Running Guide (Windows / VS Code)

### Prerequisites
1. **Python 3.10+** (Python 3.10, 3.11, 3.12, 3.13, or 3.14)
2. **Java JDK 17+** (Required by Apache Spark / PySpark; e.g. Microsoft OpenJDK 17 or Eclipse Temurin)

### Step 1: Open Terminal in Project Directory
In VS Code or PowerShell, navigate to the project directory:
```powershell
cd "C:\Users\SRI SAI TECH\.gemini\antigravity\scratch\social_media_sentiment_platform"
```

### Step 2: (Optional) Create and Activate Virtual Environment
```powershell
python -m venv venv
venv\Scripts\activate
```

### Step 3: Install Dependencies
```powershell
pip install -r requirements.txt
```

### Step 4: Run the Application
```powershell
python app.py
```

### Step 5: Open the Web Dashboard
Open your web browser and navigate to:
```text
http://127.0.0.1:5000
```

---

## 8. Dashboard Demonstration Workflow

To demonstrate the complete platform to professors, examiners, or peers:

1. **Step 1 — Ingestion (Module 1)**:
   * View the loaded dataset statistics (1,000 records, 5 platforms, 8 topics, 3 languages).
   * Search and filter posts in the raw data preview table.
2. **Step 2 — Execution (Module 2)**:
   * Click the prominent green **"RUN COMPLETE ANALYSIS"** button.
   * Observe the live execution checklist progress through preprocessing, tokenization, stop-word removal, PySpark DataFrame jobs, and VADER NLP scoring.
   * Review the **Apache Spark status card** (status, partitions, sub-second execution runtime).
   * Review the **NLP accuracy benchmarking card** (genuinely computed prediction agreement vs. reference labels).
3. **Step 3 — Interactive Analytics (Module 3)**:
   * Inspect the 6 dynamic KPI cards.
   * Explore the 8 interactive Chart.js visualizations (Distribution, Timeline Trend, Platforms, Topics, Keywords, Hashtags, Emotions, and Engagement).
   * Use the **Global Filter Toolbar** (e.g., select Platform = `Instagram` and Topic = `Technology`) to see KPIs, charts, and tables update in real time.
   * Scroll down to the **Analyzed Data Table** to see side-by-side comparisons of `Original Text`, `Processed Text`, `Predicted Sentiment`, `Predicted Score`, and `Match Status`.
4. **Step 4 — Export**:
   * Click **"Download CSV Export"** to download the analyzed dataset with predictions.
5. **Step 5 — Presentation Sections**:
   * Navigate through the built-in **System Architecture Diagram**, **Six-Stage Methodology**, **Results & Discussion**, **Limitations**, **Future Scope**, and **Cloud-Ready Roadmap**.

---

## 9. Academic Methodology (Six Connected Stages)

1. **01 — Data Collection**: Ingestion of multi-channel social records with engagement and author metadata.
2. **02 — Preprocessing**: Noise removal, text lowercasing, mention stripping, tokenization, and stop-word elimination.
3. **03 — Big Data Processing**: PySpark DataFrame distributed aggregations and scalable schema projection.
4. **04 — Sentiment Analysis**: Valence-aware polarity scoring with VADER NLP engine.
5. **05 — Data Aggregation**: Frequency extraction of keywords and hashtags, temporal trend rollups, and accuracy evaluation.
6. **06 — Visualization**: Interactive Chart.js graphs, dynamic KPI widgets, and cross-filtering.

---

## 10. Limitations & Future Scope

### Limitations
* **Computational Footprint**: Processing tens of millions of records requires multi-node cluster provisioning (e.g. AWS EMR).
* **Slang & Internet Noises**: Social text often includes abbreviations and irregular spelling.
* **Context & Sarcasm**: Sarcastic expressions present inherent ambiguity for lexicon-based classifiers.
* **Regional-Language Scope**: Lexicon analysis is optimized for English; Hinglish and Tamil records exhibit reduced accuracy.

### Future Scope
* **Live Streaming Pipelines**: Integrating Apache Kafka and Spark Streaming for sub-second live tweet/comment ingestion.
* **Multilingual Transformer Models**: Fine-tuning IndicBERT or XLM-RoBERTa for regional Indian languages.
* **Multimodal Sentiment AI**: Combining text with computer vision for image and meme sentiment detection.
* **Enterprise Cloud Deployment**: Orchestrating serverless microservices on AWS Elastic Beanstalk and Amazon EMR.

---

## 11. Cloud-Ready Architecture

| Layer | Local Academic Demo | Future Cloud Target |
| :--- | :--- | :--- |
| **Web Layer** | Python Flask (WSGI) | AWS Elastic Beanstalk / Azure App Service / GCP Cloud Run |
| **Big Data Engine** | PySpark (`local[*]`) | AWS EMR / Azure Synapse / Databricks Spark Cluster |
| **Stream Ingestion** | In-Memory / CSV Batch | Apache Kafka on Amazon MSK / Amazon Kinesis |
| **Data Lake** | Local File System | Amazon S3 / Google Cloud Storage (GCS) |
| **Inference Engine**| Local VADER NLP | AWS SageMaker / Serverless Lambda Inference |

---

## 12. Verification & Testing

To run the automated platform test suite:
```powershell
python test_platform.py
```
This tests:
* Dataset integrity and column structure
* Text preprocessing and stop-word elimination
* PySpark DataFrame creation, aggregation, and session handling
* VADER NLP sentiment score calculation and accuracy evaluation
* All Flask REST API routes (`/api/load-dataset`, `/api/process`, `/api/analytics`, `/api/results`, `/api/export`)

---

## 13. License & Academic Attribution
Created for academic demonstration and research in **Cloud Computing, Big Data Architectures, and Natural Language Processing**.
