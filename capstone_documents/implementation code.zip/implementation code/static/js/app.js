/**
 * Big Data Social Media Sentiment Analytics Platform
 * Frontend Controller & Chart.js Visualizations
 */

// Application State
const state = {
    isProcessed: false,
    previewPage: 1,
    previewPageSize: 10,
    analyzedPage: 1,
    analyzedPageSize: 10,
    charts: {},
    debounceTimer: null
};

// Color Theme
const colors = {
    positive: '#10b981',
    negative: '#ef4444',
    neutral: '#f59e0b',
    primary: '#6366f1',
    accent: '#38bdf8',
    cyan: '#06b6d4',
    purple: '#a855f7',
    pink: '#ec4899',
    chartGrid: 'rgba(255, 255, 255, 0.06)',
    chartText: '#9ca3af'
};

// Initialize App on DOM Loaded
document.addEventListener('DOMContentLoaded', () => {
    loadDefaultDataset();
});

// Toast Notification
function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    let icon = 'fa-circle-info';
    if (type === 'success') icon = 'fa-circle-check';
    if (type === 'error') icon = 'fa-triangle-exclamation';

    toast.innerHTML = `<i class="fa-solid ${icon}"></i> <span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

// -------------------------------------------------------------
// MODULE 1: DATA INGESTION & PREVIEW
// -------------------------------------------------------------

async function loadDefaultDataset() {
    try {
        setSystemStatus('Loading dataset...', 'live');
        const res = await fetch('/api/load-dataset');
        const data = await res.json();

        if (data.success) {
            updateValidationUI(data.validation, data.dataset_info);
            renderPreviewTable(data.preview_records, data.validation.total_records);
            showToast('Benchmark dataset (1,000 posts) loaded & validated.', 'success');
            setSystemStatus('● System Ready', 'live');
        } else {
            showToast(data.error || 'Failed to load dataset', 'error');
            setSystemStatus('● Error Loading Data', 'error');
        }
    } catch (err) {
        console.error(err);
        showToast('Network error loading dataset', 'error');
        setSystemStatus('● Disconnected', 'error');
    }
}

async function handleFileUpload(event) {
    const file = event.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);

    try {
        setSystemStatus('Uploading custom dataset...', 'live');
        const res = await fetch('/api/upload', {
            method: 'POST',
            body: formData
        });
        const data = await res.json();

        if (data.success) {
            document.getElementById('active-file-tag').innerText = file.name;
            updateValidationUI(data.validation, data.dataset_info);
            renderPreviewTable(data.preview_records, data.validation.total_records);
            showToast(`Custom CSV "${file.name}" loaded successfully.`, 'success');
            setSystemStatus('● System Ready', 'live');
        } else {
            showToast(data.error || 'Upload validation failed', 'error');
            setSystemStatus('● Validation Failed', 'error');
        }
    } catch (err) {
        console.error(err);
        showToast('Failed to upload file', 'error');
        setSystemStatus('● Upload Error', 'error');
    }
}

function updateValidationUI(val, info) {
    document.getElementById('val-total-records').innerText = (val.total_records || 0).toLocaleString();
    document.getElementById('val-missing-text').innerText = (val.missing_text_count || 0).toLocaleString();
    document.getElementById('val-duplicates').innerText = (val.duplicate_count || 0).toLocaleString();
    document.getElementById('val-platforms').innerText = val.platform_count || 0;
    document.getElementById('val-languages').innerText = val.language_count || 0;
    document.getElementById('val-topics').innerText = val.topic_count || 0;
    document.getElementById('val-date-range').innerText = val.date_range || 'N/A';
    
    const statusTag = document.getElementById('dataset-status-tag');
    if (val.is_valid) {
        statusTag.className = 'tag tag-success';
        statusTag.innerText = 'Dataset Status: Valid';
    } else {
        statusTag.className = 'tag tag-danger';
        statusTag.innerText = 'Dataset Status: Invalid';
    }

    document.getElementById('file-records-label').innerText = `${(val.total_records || 0).toLocaleString()} records ready`;
    document.getElementById('kpi-total-posts').innerText = (val.total_records || 0).toLocaleString();
}

async function fetchPreviewPage() {
    const search = document.getElementById('preview-search-input').value;
    const platform = document.getElementById('preview-platform-filter').value;

    const params = new URLSearchParams({
        page: state.previewPage,
        page_size: state.previewPageSize,
        search: search,
        platform: platform
    });

    try {
        const res = await fetch(`/api/results?${params}`);
        const data = await res.json();
        if (data.success) {
            renderPreviewTable(data.records, data.total);
        }
    } catch (err) {
        console.error(err);
    }
}

function renderPreviewTable(records, total) {
    const tbody = document.getElementById('preview-table-body');
    tbody.innerHTML = '';

    if (!records || records.length === 0) {
        tbody.innerHTML = `<tr><td colspan="10" style="text-align:center; padding: 2rem; color: var(--text-muted);">No records found matching criteria.</td></tr>`;
        document.getElementById('preview-pagination-info').innerText = 'Showing 0 records';
        return;
    }

    records.forEach(r => {
        const tr = document.createElement('tr');
        
        let sentClass = 'tag-info';
        const sentLower = (r.sentiment || '').toLowerCase();
        if (sentLower.includes('pos')) sentClass = 'tag-success';
        if (sentLower.includes('neg')) sentClass = 'tag-danger';
        if (sentLower.includes('neu')) sentClass = 'tag-warning';

        tr.innerHTML = `
            <td><strong class="font-mono text-accent">${r.post_id || ''}</strong></td>
            <td><span class="tag tag-accent">${r.platform || ''}</span></td>
            <td><span class="font-mono" style="font-size:0.75rem;">${r.timestamp || ''}</span></td>
            <td><span class="text-muted">@${r.username || ''}</span></td>
            <td style="max-width: 280px;"><span title="${r.text || ''}">${truncateText(r.text || '', 60)}</span></td>
            <td>${r.language || ''}</td>
            <td><span class="tag tag-info">${r.topic || ''}</span></td>
            <td><span class="tag ${sentClass}">${r.sentiment || ''}</span></td>
            <td><span class="text-muted font-mono">${r.emotion || ''}</span></td>
            <td><span class="font-mono text-success">${(r.likes || 0).toLocaleString()} <i class="fa-solid fa-heart"></i></span></td>
        `;
        tbody.appendChild(tr);
    });

    const start = (state.previewPage - 1) * state.previewPageSize + 1;
    const end = Math.min(start + records.length - 1, total);
    document.getElementById('preview-pagination-info').innerText = `Showing ${start} to ${end} of ${total.toLocaleString()} records`;
    document.getElementById('preview-page-num').innerText = state.previewPage;

    document.getElementById('prev-preview-btn').disabled = (state.previewPage <= 1);
    document.getElementById('next-preview-btn').disabled = (end >= total);
}

function handlePreviewSearch() {
    state.previewPage = 1;
    fetchPreviewPage();
}

function handlePreviewFilterChange() {
    state.previewPage = 1;
    fetchPreviewPage();
}

function prevPreviewPage() {
    if (state.previewPage > 1) {
        state.previewPage--;
        fetchPreviewPage();
    }
}

function nextPreviewPage() {
    state.previewPage++;
    fetchPreviewPage();
}


// -------------------------------------------------------------
// MODULE 2: RUN COMPLETE ANALYSIS & PROCESSING
// -------------------------------------------------------------

async function runCompleteAnalysis() {
    const btn = document.getElementById('run-analysis-btn');
    btn.disabled = true;
    btn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> EXECUTING PIPELINE...`;
    setSystemStatus('Processing Pipeline Active...', 'live');

    // Animate checklist steps progressively
    animateChecklist();

    try {
        const res = await fetch('/api/process', { method: 'POST' });
        const data = await res.json();

        if (data.success) {
            state.isProcessed = true;
            markAllChecklistDone();

            // Update Spark Engine Card
            const spark = data.spark_metadata || {};
            document.getElementById('spark-status-tag').className = 'tag tag-success';
            document.getElementById('spark-status-tag').innerText = 'Status: Completed';
            document.getElementById('spark-records-count').innerText = `${(spark.records_processed || 1000).toLocaleString()} Records`;
            document.getElementById('spark-partitions').innerText = `${spark.num_partitions || 12} Spark Partitions`;
            document.getElementById('spark-runtime').innerText = `${spark.execution_time_seconds || 0.45} s`;

            // Update NLP Benchmarking Card
            const nlp = data.nlp_comparison || {};
            const acc = nlp.accuracy_percentage || 0;
            document.getElementById('nlp-accuracy-val').innerText = `${acc}%`;
            document.getElementById('nlp-match-count').innerText = (nlp.matching_predictions || 0).toLocaleString();
            document.getElementById('nlp-diff-count').innerText = (nlp.different_predictions || 0).toLocaleString();
            document.getElementById('nlp-total-eval').innerText = (nlp.total_records || 1000).toLocaleString();
            document.getElementById('nlp-acc-bar-text').innerText = `${acc}% Agreement`;
            document.getElementById('nlp-accuracy-bar').style.width = `${acc}%`;

            // Update Results & Discussion Stats
            document.getElementById('res-matching-pct').innerText = `${acc}%`;
            document.getElementById('res-runtime').innerText = `${spark.execution_time_seconds || 0.45}s`;

            // Update KPI Cards & Charts
            updateKPIs(data.analytics.kpis);
            renderAllCharts(data.analytics);
            renderPlatformTable(data.analytics.platform_analytics.table);
            renderLanguageList(data.analytics.language_analytics.languages);
            renderTopPostsList(data.analytics.engagement_analytics.top_posts);

            // Fetch analyzed table
            state.analyzedPage = 1;
            fetchAnalyzedPage();

            showToast('Complete pipeline executed: Preprocessing → Spark → VADER NLP → Visual Dashboard.', 'success');
            setSystemStatus('● Pipeline Completed', 'live');
            document.getElementById('sidebar-status').innerText = 'Spark & NLP Active';
        } else {
            showToast(data.error || 'Pipeline execution failed', 'error');
            setSystemStatus('● Processing Failed', 'error');
        }
    } catch (err) {
        console.error(err);
        showToast('Network error during analysis execution', 'error');
        setSystemStatus('● Execution Error', 'error');
    } finally {
        btn.disabled = false;
        btn.innerHTML = `<i class="fa-solid fa-bolt"></i> RUN COMPLETE ANALYSIS`;
    }
}

function animateChecklist() {
    const steps = [
        'step-preprocess', 'step-tokenize', 'step-stopwords', 
        'step-spark', 'step-nlp', 'step-classify', 'step-analytics', 'step-dashboard'
    ];
    steps.forEach((s, idx) => {
        setTimeout(() => {
            const el = document.getElementById(s);
            if (el) {
                el.className = 'check-item done';
                el.querySelector('i').className = 'fa-solid fa-circle-check';
            }
        }, (idx + 1) * 300);
    });
}

function markAllChecklistDone() {
    document.querySelectorAll('.check-item').forEach(el => {
        el.className = 'check-item done';
        el.querySelector('i').className = 'fa-solid fa-circle-check';
    });
    const execTag = document.getElementById('overall-exec-tag');
    if (execTag) {
        execTag.className = 'tag tag-success';
        execTag.innerText = 'Completed';
    }
}


// -------------------------------------------------------------
// MODULE 3: VISUALIZATION DASHBOARD & CHARTS
// -------------------------------------------------------------

function updateKPIs(kpis) {
    if (!kpis) return;
    document.getElementById('kpi-total-posts').innerText = (kpis.total_posts || 0).toLocaleString();
    document.getElementById('kpi-pos-count').innerText = (kpis.positive_count || 0).toLocaleString();
    document.getElementById('kpi-pos-pct').innerText = `${kpis.positive_pct || 0}% of total`;
    
    document.getElementById('kpi-neg-count').innerText = (kpis.negative_count || 0).toLocaleString();
    document.getElementById('kpi-neg-pct').innerText = `${kpis.negative_pct || 0}% of total`;

    document.getElementById('kpi-neu-count').innerText = (kpis.neutral_count || 0).toLocaleString();
    document.getElementById('kpi-neu-pct').innerText = `${kpis.neutral_pct || 0}% of total`;

    document.getElementById('kpi-avg-score').innerText = (kpis.avg_sentiment_score > 0 ? '+' : '') + (kpis.avg_sentiment_score || 0.0);
    document.getElementById('kpi-avg-engagement').innerText = `${kpis.avg_engagement_rate || 0}%`;
}

function renderAllCharts(analytics) {
    if (!analytics) return;

    // Chart 1: Sentiment Distribution (Doughnut)
    renderSentimentDistChart(analytics.sentiment_distribution);

    // Chart 2: Sentiment Trend (Line)
    renderSentimentTrendChart(analytics.sentiment_trend);

    // Chart 3: Platform Sentiment (Grouped Bar)
    renderPlatformSentimentChart(analytics.platform_analytics);

    // Chart 4: Topic Sentiment (Grouped Bar)
    renderTopicSentimentChart(analytics.topic_analytics);

    // Chart 5: Top Keywords (Bar)
    renderTopKeywordsChart(analytics.top_keywords);

    // Chart 6: Top Hashtags (Bar)
    renderTopHashtagsChart(analytics.top_hashtags);

    // Chart 7: Emotion Distribution (PolarArea/Doughnut)
    renderEmotionDistChart(analytics.emotion_analytics);

    // Chart 8: Engagement by Sentiment (Bar)
    renderEngagementSentimentChart(analytics.engagement_analytics);
}

// Chart 1
function renderSentimentDistChart(dist) {
    const ctx = document.getElementById('chart-sentiment-dist');
    if (!ctx) return;
    if (state.charts.dist) state.charts.dist.destroy();

    const data = [dist.Positive || 0, dist.Negative || 0, dist.Neutral || 0];

    state.charts.dist = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Positive', 'Negative', 'Neutral'],
            datasets: [{
                data: data,
                backgroundColor: [colors.positive, colors.negative, colors.neutral],
                borderColor: '#111827',
                borderWidth: 3,
                hoverOffset: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: colors.chartText, font: { family: 'Plus Jakarta Sans', weight: '600' } }
                }
            },
            cutout: '68%'
        }
    });
}

// Chart 2
function renderSentimentTrendChart(trend) {
    const ctx = document.getElementById('chart-sentiment-trend');
    if (!ctx) return;
    if (state.charts.trend) state.charts.trend.destroy();

    state.charts.trend = new Chart(ctx, {
        type: 'line',
        data: {
            labels: trend.labels || [],
            datasets: [
                {
                    label: 'Positive',
                    data: trend.positive || [],
                    borderColor: colors.positive,
                    backgroundColor: 'rgba(16, 185, 129, 0.12)',
                    tension: 0.35,
                    fill: true
                },
                {
                    label: 'Negative',
                    data: trend.negative || [],
                    borderColor: colors.negative,
                    backgroundColor: 'rgba(239, 68, 68, 0.12)',
                    tension: 0.35,
                    fill: true
                },
                {
                    label: 'Neutral',
                    data: trend.neutral || [],
                    borderColor: colors.neutral,
                    backgroundColor: 'rgba(245, 158, 11, 0.12)',
                    tension: 0.35,
                    fill: true
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { labels: { color: colors.chartText } }
            },
            scales: {
                x: { grid: { color: colors.chartGrid }, ticks: { color: colors.chartText } },
                y: { grid: { color: colors.chartGrid }, ticks: { color: colors.chartText } }
            }
        }
    });
}

// Chart 3
function renderPlatformSentimentChart(pAnalytics) {
    const ctx = document.getElementById('chart-platform-sentiment');
    if (!ctx) return;
    if (state.charts.platform) state.charts.platform.destroy();

    state.charts.platform = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: pAnalytics.labels || [],
            datasets: [
                { label: 'Positive', data: pAnalytics.positive || [], backgroundColor: colors.positive, borderRadius: 4 },
                { label: 'Negative', data: pAnalytics.negative || [], backgroundColor: colors.negative, borderRadius: 4 },
                { label: 'Neutral', data: pAnalytics.neutral || [], backgroundColor: colors.neutral, borderRadius: 4 }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { labels: { color: colors.chartText } } },
            scales: {
                x: { grid: { display: false }, ticks: { color: colors.chartText } },
                y: { grid: { color: colors.chartGrid }, ticks: { color: colors.chartText } }
            }
        }
    });
}

// Chart 4
function renderTopicSentimentChart(tAnalytics) {
    const ctx = document.getElementById('chart-topic-sentiment');
    if (!ctx) return;
    if (state.charts.topic) state.charts.topic.destroy();

    state.charts.topic = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: tAnalytics.labels || [],
            datasets: [
                { label: 'Positive', data: tAnalytics.positive || [], backgroundColor: colors.positive, borderRadius: 4 },
                { label: 'Negative', data: tAnalytics.negative || [], backgroundColor: colors.negative, borderRadius: 4 },
                { label: 'Neutral', data: tAnalytics.neutral || [], backgroundColor: colors.neutral, borderRadius: 4 }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { labels: { color: colors.chartText } } },
            scales: {
                x: { grid: { display: false }, ticks: { color: colors.chartText, maxRotation: 45 } },
                y: { grid: { color: colors.chartGrid }, ticks: { color: colors.chartText } }
            }
        }
    });
}

// Chart 5
function renderTopKeywordsChart(keywords) {
    const ctx = document.getElementById('chart-top-keywords');
    if (!ctx) return;
    if (state.charts.keywords) state.charts.keywords.destroy();

    const labels = (keywords || []).map(k => k.word);
    const data = (keywords || []).map(k => k.count);

    state.charts.keywords = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Frequency',
                data: data,
                backgroundColor: colors.primary,
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: 'y',
            plugins: { legend: { display: false } },
            scales: {
                x: { grid: { color: colors.chartGrid }, ticks: { color: colors.chartText } },
                y: { grid: { display: false }, ticks: { color: colors.chartText } }
            }
        }
    });
}

// Chart 6
function renderTopHashtagsChart(hashtags) {
    const ctx = document.getElementById('chart-top-hashtags');
    if (!ctx) return;
    if (state.charts.hashtags) state.charts.hashtags.destroy();

    const labels = (hashtags || []).map(h => h.hashtag);
    const data = (hashtags || []).map(h => h.count);

    state.charts.hashtags = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Tag Frequency',
                data: data,
                backgroundColor: colors.accent,
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: { grid: { display: false }, ticks: { color: colors.chartText, maxRotation: 45 } },
                y: { grid: { color: colors.chartGrid }, ticks: { color: colors.chartText } }
            }
        }
    });
}

// Chart 7
function renderEmotionDistChart(emotion) {
    const ctx = document.getElementById('chart-emotion-dist');
    if (!ctx) return;
    if (state.charts.emotion) state.charts.emotion.destroy();

    const palette = [
        '#6366f1', '#38bdf8', '#10b981', '#f59e0b', '#ef4444', 
        '#ec4899', '#8b5cf6', '#14b8a6', '#f97316', '#06b6d4', '#64748b', '#84cc16'
    ];

    state.charts.emotion = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: emotion.labels || [],
            datasets: [{
                data: emotion.counts || [],
                backgroundColor: palette,
                borderColor: '#111827',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'right', labels: { color: colors.chartText, boxWidth: 12 } }
            },
            cutout: '55%'
        }
    });
}

// Chart 8
function renderEngagementSentimentChart(eng) {
    const ctx = document.getElementById('chart-engagement-sentiment');
    if (!ctx) return;
    if (state.charts.engagement) state.charts.engagement.destroy();

    state.charts.engagement = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: eng.categories || ['Positive', 'Negative', 'Neutral'],
            datasets: [
                { label: 'Avg Likes', data: eng.avg_likes || [], backgroundColor: colors.cyan, borderRadius: 4 },
                { label: 'Avg Shares', data: eng.avg_shares || [], backgroundColor: colors.primary, borderRadius: 4 },
                { label: 'Avg Comments', data: eng.avg_comments || [], backgroundColor: colors.accent, borderRadius: 4 }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { labels: { color: colors.chartText } } },
            scales: {
                x: { grid: { display: false }, ticks: { color: colors.chartText } },
                y: { grid: { color: colors.chartGrid }, ticks: { color: colors.chartText } }
            }
        }
    });
}

// Render Platform Summary Table
function renderPlatformTable(platforms) {
    const tbody = document.getElementById('platform-table-body');
    if (!tbody) return;
    tbody.innerHTML = '';

    (platforms || []).forEach(p => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td><strong>${p.platform}</strong></td>
            <td>${p.total_posts.toLocaleString()}</td>
            <td><span class="text-success font-mono">${p.positive}</span></td>
            <td><span class="text-danger font-mono">${p.negative}</span></td>
            <td><span class="text-warning font-mono">${p.neutral}</span></td>
            <td><strong class="text-accent">${p.avg_engagement}%</strong></td>
            <td>${p.total_likes.toLocaleString()}</td>
            <td>${p.total_shares.toLocaleString()}</td>
            <td>${p.total_comments.toLocaleString()}</td>
        `;
        tbody.appendChild(tr);
    });
}

// Render Language Breakdown
function renderLanguageList(languages) {
    const container = document.getElementById('language-list-container');
    if (!container) return;
    container.innerHTML = '';

    (languages || []).forEach(l => {
        const div = document.createElement('div');
        div.className = 'lang-item-row';
        div.innerHTML = `
            <div class="lang-header">
                <strong>${l.language}</strong>
                <span>${l.count.toLocaleString()} posts (${l.pct}%)</span>
            </div>
            <div class="progress-bar-bg">
                <div class="progress-bar-fill" style="width: ${l.pct}%;"></div>
            </div>
        `;
        container.appendChild(div);
    });
}

// Render Top 5 Engaged Posts
function renderTopPostsList(posts) {
    const container = document.getElementById('top-posts-list');
    if (!container) return;
    container.innerHTML = '';

    (posts || []).forEach(p => {
        const card = document.createElement('div');
        card.className = 'top-post-card';
        card.innerHTML = `
            <div class="top-post-meta">
                <span class="tag tag-accent">${p.platform}</span>
                <span class="text-muted">@${p.username}</span>
                <span class="tag tag-${p.sentiment === 'Positive' ? 'success' : (p.sentiment === 'Negative' ? 'danger' : 'warning')}">${p.sentiment}</span>
            </div>
            <div class="top-post-text">${p.text}</div>
            <div class="top-post-metrics">
                <span><i class="fa-solid fa-heart text-danger"></i> ${(p.likes || 0).toLocaleString()}</span>
                <span><i class="fa-solid fa-share text-accent"></i> ${(p.shares || 0).toLocaleString()}</span>
                <span><i class="fa-solid fa-comment text-warning"></i> ${(p.comments || 0).toLocaleString()}</span>
                <span><strong class="text-success">${p.engagement_rate}% Eng</strong></span>
            </div>
        `;
        container.appendChild(card);
    });
}


// -------------------------------------------------------------
// ANALYZED DATA TABLE & FILTERS
// -------------------------------------------------------------

function getActiveFilters() {
    return {
        platform: document.getElementById('filter-platform').value,
        sentiment: document.getElementById('filter-sentiment').value,
        topic: document.getElementById('filter-topic').value,
        language: document.getElementById('filter-language').value,
        location: document.getElementById('filter-location').value,
        search: document.getElementById('filter-search').value.trim()
    };
}

async function applyGlobalFilters() {
    const filters = getActiveFilters();
    const params = new URLSearchParams(filters);

    try {
        // 1. Fetch updated Analytics for KPIs and Charts
        const aRes = await fetch(`/api/analytics?${params}`);
        const aData = await aRes.json();
        if (aData.success) {
            updateKPIs(aData.analytics.kpis);
            renderAllCharts(aData.analytics);
            renderPlatformTable(aData.analytics.platform_analytics.table);
            renderLanguageList(aData.analytics.language_analytics.languages);
            renderTopPostsList(aData.analytics.engagement_analytics.top_posts);
        }

        // 2. Fetch updated Analyzed Data Table
        state.analyzedPage = 1;
        fetchAnalyzedPage();
    } catch (err) {
        console.error(err);
    }
}

function debounceApplyFilters() {
    clearTimeout(state.debounceTimer);
    state.debounceTimer = setTimeout(() => {
        applyGlobalFilters();
    }, 300);
}

function resetFilters() {
    document.getElementById('filter-platform').value = 'all';
    document.getElementById('filter-sentiment').value = 'all';
    document.getElementById('filter-topic').value = 'all';
    document.getElementById('filter-language').value = 'all';
    document.getElementById('filter-location').value = 'all';
    document.getElementById('filter-search').value = '';
    applyGlobalFilters();
    showToast('Filters reset to default view.', 'info');
}

async function fetchAnalyzedPage() {
    const filters = getActiveFilters();
    const params = new URLSearchParams({
        page: state.analyzedPage,
        page_size: state.analyzedPageSize,
        ...filters
    });

    try {
        const res = await fetch(`/api/results?${params}`);
        const data = await res.json();
        if (data.success) {
            renderAnalyzedTable(data.records, data.total);
        }
    } catch (err) {
        console.error(err);
    }
}

function renderAnalyzedTable(records, total) {
    const tbody = document.getElementById('analyzed-table-body');
    if (!tbody) return;
    tbody.innerHTML = '';

    if (!records || records.length === 0) {
        tbody.innerHTML = `<tr><td colspan="17" style="text-align:center; padding: 2rem; color: var(--text-muted);">No analyzed records found. Click "RUN COMPLETE ANALYSIS" to generate sentiment predictions.</td></tr>`;
        document.getElementById('analyzed-pagination-info').innerText = 'Showing 0 records';
        return;
    }

    records.forEach(r => {
        const tr = document.createElement('tr');

        const pred = r.predicted_sentiment || r.sentiment || 'Neutral';
        let predClass = 'tag-warning';
        if (pred === 'Positive') predClass = 'tag-success';
        if (pred === 'Negative') predClass = 'tag-danger';

        const isMatch = r.sentiment_match !== undefined ? r.sentiment_match : (pred.toLowerCase() === (r.sentiment || '').toLowerCase());
        const matchBadge = isMatch ? '<span class="tag tag-success"><i class="fa-solid fa-check"></i> Match</span>' : '<span class="tag tag-warning"><i class="fa-solid fa-xmark"></i> Diff</span>';

        tr.innerHTML = `
            <td><strong class="font-mono text-accent">${r.post_id || ''}</strong></td>
            <td><span class="tag tag-accent">${r.platform || ''}</span></td>
            <td style="max-width: 200px;"><span title="${r.original_text || r.text || ''}">${truncateText(r.original_text || r.text || '', 40)}</span></td>
            <td style="max-width: 180px;"><span class="font-mono text-muted" title="${r.processed_text || ''}">${truncateText(r.processed_text || '', 35)}</span></td>
            <td><span class="tag ${predClass}">${pred}</span></td>
            <td><span class="font-mono ${r.predicted_score >= 0 ? 'text-success' : 'text-danger'}">${r.predicted_score !== undefined ? (r.predicted_score > 0 ? '+' : '') + r.predicted_score : '--'}</span></td>
            <td><span class="text-muted font-mono">${r.reference_sentiment || r.sentiment || '--'}</span></td>
            <td>${matchBadge}</td>
            <td><span class="tag tag-info">${r.topic || ''}</span></td>
            <td>${r.language || ''}</td>
            <td><span class="text-muted">${r.emotion || ''}</span></td>
            <td>${(r.likes || 0).toLocaleString()}</td>
            <td>${(r.shares || 0).toLocaleString()}</td>
            <td>${(r.comments || 0).toLocaleString()}</td>
            <td><span class="text-accent" style="font-size:0.75rem;">${truncateText(r.hashtags || '', 25)}</span></td>
            <td>${r.location || 'Unknown'}</td>
            <td><strong class="text-success">${r.engagement_rate || 0}%</strong></td>
        `;
        tbody.appendChild(tr);
    });

    const start = (state.analyzedPage - 1) * state.analyzedPageSize + 1;
    const end = Math.min(start + records.length - 1, total);
    document.getElementById('analyzed-pagination-info').innerText = `Showing ${start} to ${end} of ${total.toLocaleString()} records`;
    document.getElementById('analyzed-page-num').innerText = state.analyzedPage;

    document.getElementById('prev-analyzed-btn').disabled = (state.analyzedPage <= 1);
    document.getElementById('next-analyzed-btn').disabled = (end >= total);
}

function prevAnalyzedPage() {
    if (state.analyzedPage > 1) {
        state.analyzedPage--;
        fetchAnalyzedPage();
    }
}

function nextAnalyzedPage() {
    state.analyzedPage++;
    fetchAnalyzedPage();
}

function exportDataCSV() {
    const filters = getActiveFilters();
    const params = new URLSearchParams(filters);
    window.location.href = `/api/export?${params}`;
    showToast('Exporting analyzed dataset as CSV...', 'info');
}


// -------------------------------------------------------------
// HELPER FUNCTIONS
// -------------------------------------------------------------

function setSystemStatus(text, type = 'live') {
    const el = document.getElementById('system-status-text');
    if (el) el.innerText = text;
}

function truncateText(str, maxLen = 50) {
    if (!str) return '';
    return str.length > maxLen ? str.substring(0, maxLen) + '...' : str;
}
